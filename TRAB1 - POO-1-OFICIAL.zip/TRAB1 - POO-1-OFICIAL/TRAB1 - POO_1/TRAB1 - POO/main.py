from config_jogo import ConfigJogo
from jogo import Jogo_Toninha


def main():
    jogo = Jogo_Toninha()
    jogo.rodar()


if __name__ == "__main__":
    main()
