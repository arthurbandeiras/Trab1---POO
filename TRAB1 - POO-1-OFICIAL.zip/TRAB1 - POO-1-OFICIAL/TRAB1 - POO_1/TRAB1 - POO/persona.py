import pygame as pg
from personagem_bat import Personagem_batalha
from config_jogo import load_image

#====================================================
#           definição dos personagens
#====================================================

#TODO: como identificar o movimento especial do personagem?
#TODO: colocar as sprites nos personagens 

def img(diretorio):
    return pg.image.load(diretorio)

def scale(imagem, resolucao):
    return pg.transform.scale(imagem, resolucao)

##########################################################################

sprite_maga_d = scale(img(r'.\sprites\Toninha_maga.png'), (82, 82))
sprite_maga_e = pg.transform.flip(sprite_maga_d, True, False)

sprite_golem_d = scale(img(r'.\sprites\toninha_golem.png'), (82, 82))
sprite_golem_e = pg.transform.flip(sprite_golem_d, True, False)

sprite_rei_d = scale(img(r'.\sprites\toninha_rei.png'), (82, 82))
sprite_rei_e = pg.transform.flip(sprite_rei_d, True, False)

sprite_monge_d = scale(img(r'.\sprites\toninha_monge.png'), (82, 82))
sprite_monge_e = pg.transform.flip(sprite_monge_d, True, False)

##########################################################################

sprite_atirador_e = scale(img(r'.\sprites\soldado_atirador.png'), (82, 82))
sprite_atirador_d = pg.transform.flip(sprite_atirador_e, True, False)

sprite_parrudo_e = scale(img(r'.\sprites\soldado_parrudo.png'), (82, 82))
sprite_parrudo_d = pg.transform.flip(sprite_parrudo_e, True, False)

sprite_general_e = scale(img(r'.\sprites\soldado_general.png'), (82, 82))
sprite_general_d = pg.transform.flip(sprite_general_e, True, False)

sprite_medico_e = scale(img(r'.\sprites\soldado_medico.png'), (82, 82))
sprite_medico_d = pg.transform.flip(sprite_medico_e, True, False)

sprite_amogus1 = scale(img(r'.\sprites\amogus_walk1.png'), (82, 82))
sprite_amogus2 = scale(img(r'.\sprites\amogus_walk2.png'), (82, 82))

toninha_maga = Personagem_batalha("Toninha Maga", 50, 15, 1, (0, 0),0, sprite_maga_d, sprite_maga_e)
toninha_golem = Personagem_batalha("Toninha Golen", 150, 30, 0.5, (0, 0),0, sprite_golem_d, sprite_golem_e)
toninha_rei = Personagem_batalha("Toninha Rei", 70, 15, 1.5, (0, 0),0, sprite_rei_d, sprite_rei_e)        #gerador de minions
toninha_monge = Personagem_batalha("Toninha Monge", 90, 15, 2, (0, 0),0, sprite_monge_d, sprite_monge_e)

soldado_atirador = Personagem_batalha("Soldado Atirador", 50, 15, 1, (0, 0),1, sprite_atirador_d, sprite_atirador_e)
soldado_parrudo = Personagem_batalha("Soldado Parrudo", 150, 30, 0.5, (0, 0),1, sprite_parrudo_d, sprite_parrudo_e)
soldado_general = Personagem_batalha("General", 70, 15, 1.5, (0, 0),1, sprite_general_d, sprite_general_e)        #gerador de minions
soldado_medico = Personagem_batalha("Soldado Medico", 90, 15, 2, (0, 0),1, sprite_medico_d, sprite_medico_e)

amogus1 = Personagem_batalha("AMOGUS", 70, 15, 1.5, (0, 0),0, sprite_amogus1, sprite_amogus2)
amogus2 = Personagem_batalha("AMOGUS", 70, 15, 1.5, (0, 0),0, sprite_amogus1, sprite_amogus2)

Lista1 = [toninha_maga, toninha_golem, toninha_rei, toninha_monge, amogus1]
Lista2 = [soldado_atirador, soldado_parrudo, soldado_general, soldado_medico, amogus2]


#====================================================
#               definição dos ataques
#====================================================


